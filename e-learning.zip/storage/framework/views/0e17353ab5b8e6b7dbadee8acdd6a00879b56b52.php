


<?php $__env->startSection('content'); ?>
<section class="section hero hero-bg text-center">
    <div class="container">
        <h1 class="hero-title">
            Bienvenido a nuestro portal de servicios
        </h1>

        <p class="hero-subtitle mt-3">
            Encuentra y contrata profesionales confiables para todo tipo de servicios.
        </p>

        <p class="hero-question mt-4">¿Qué servicio necesitas?</p>

        <div class="row justify-content-center mt-3">
            <div class="col-md-7">
                <form class="search-hero">
                    <input type="text" placeholder="Buscar servicio, especialista o categoría">
                    <button type="submit">🔍</button>
                </form>
            </div>
        </div>

        <p class="hero-extra mt-4">
            Todos nuestros servicios verificados.<br>
            <strong>O administra tus servicios como proveedor.</strong>
        </p>
    </div>
</section>

<section class="section bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5">Servicios Destacados</h2>

        <div class="row">
            <div class="col-md-4 mb-4">
                <div class="program-card">
                    <img src="https://via.placeholder.com/400x180" alt="Servicio 1">

                    <div class="program-body">
                        <span class="program-type">Hogar</span>
                        <h5>Limpieza Profesional</h5>
                        <p>Limpieza profunda de hogares y oficinas.</p>
                        <div class="program-meta">Disponible • 24/7</div>
                        <div class="program-actions">
                            <a href="#" class="btn btn-primary btn-sm">Contratar</a>
                            <a href="#" class="btn btn-outline-primary btn-sm">Ver detalles</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="program-card">
                    <img src="https://via.placeholder.com/400x180" alt="Servicio 2">
                    <div class="program-body">
                        <span class="program-type">Tecnología</span>
                        <h5>Soporte Técnico</h5>
                        <p>Reparación de computadoras y equipos electrónicos.</p>
                        <div class="program-meta">Disponible • Horario laboral</div>
                        <div class="program-actions">
                            <a href="#" class="btn btn-primary btn-sm">Contratar</a>
                            <a href="#" class="btn btn-outline-primary btn-sm">Ver detalles</a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-4 mb-4">
                <div class="program-card">
                    <img src="https://via.placeholder.com/400x180" alt="Servicio 3">
                    <div class="program-body">
                        <span class="program-type">Salud</span>
                        <h5>Asistencia Médica</h5>
                        <p>Profesionales de la salud disponibles a domicilio.</p>
                        <div class="program-meta">Disponible • Urgencias</div>
                        <div class="program-actions">
                            <a href="#" class="btn btn-primary btn-sm">Contratar</a>
                            <a href="#" class="btn btn-outline-primary btn-sm">Ver detalles</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="section why-esipec">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h2 class="why-title">Por qué elegirnos</h2>

                <div class="why-list">
                    <div class="why-item">
                        <div class="why-icon">
                            <i class="fas fa-user-check" style="font-size:30px;color:#00B4E6;"></i>
                        </div>
                        <div>
                            <h5>Profesionales verificados</h5>
                            <p>Todos nuestros proveedores están certificados y evaluados.</p>
                        </div>
                    </div>

                    <div class="why-item">
                        <div class="why-icon">
                            <i class="fas fa-clock" style="font-size:30px;color:#00B4E6;"></i>
                        </div>
                        <div>
                            <h5>Disponibilidad 24/7</h5>
                            <p>Contrata servicios en cualquier momento, con horarios flexibles.</p>
                        </div>
                    </div>

                    <div class="why-item">
                        <div class="why-icon">
                            <i class="fas fa-shield-alt" style="font-size:30px;color:#00B4E6;"></i>
                        </div>
                        <div>
                            <h5>Seguridad garantizada</h5>
                            <p>Pagos seguros y protección en todas las contrataciones.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-6 text-center">
                <img src="https://via.placeholder.com/400x350" alt="Servicios destacados" class="why-image">
            </div>
        </div>
    </div>
</section>

<section class="section docentes bg-light">
    <div class="container">
        <h2 class="section-title text-center mb-5">Proveedores Destacados</h2>

        <div class="row justify-content-center">
            <div class="col-md-4 col-sm-6 mb-4">
                <div class="docente-card">
                    <div class="docente-photo">
                        <img src="https://via.placeholder.com/180" alt="Proveedor 1">
                    </div>
                    <h5>María López</h5>
                    <p>Limpieza profesional</p>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 mb-4">
                <div class="docente-card">
                    <div class="docente-photo">
                        <img src="https://via.placeholder.com/180" alt="Proveedor 2">
                    </div>
                    <h5>Carlos Pérez</h5>
                    <p>Soporte Técnico</p>
                </div>
            </div>

            <div class="col-md-4 col-sm-6 mb-4">
                <div class="docente-card">
                    <div class="docente-photo">
                        <img src="https://via.placeholder.com/180" alt="Proveedor 3">
                    </div>
                    <h5>Lucía Martínez</h5>
                    <p>Enfermería a domicilio</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="benefits-pro">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-5 mb-4 mb-lg-0 text-center">
                <img src="https://via.placeholder.com/400x300" class="benefits-img" alt="Beneficios">
            </div>

            <div class="col-lg-7">
                <h2 class="section-title mb-4">Beneficios de usar nuestra plataforma</h2>

                <div class="row">
                    <div class="col-md-6 col-lg-6 mb-4">
                        <div class="benefit-card">
                            <div class="benefit-icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                            <p>Servicios verificados y confiables</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 mb-4">
                        <div class="benefit-card">
                            <div class="benefit-icon">
                                <i class="fas fa-wallet"></i>
                            </div>
                            <p>Pagos seguros y seguimiento en tiempo real</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 mb-4">
                        <div class="benefit-card">
                            <div class="benefit-icon">
                                <i class="fas fa-star"></i>
                            </div>
                            <p>Calificaciones y reseñas de clientes</p>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-6 mb-4">
                        <div class="benefit-card">
                            <div class="benefit-icon">
                                <i class="fas fa-mobile-alt"></i>
                            </div>
                            <p>Acceso desde cualquier dispositivo</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/student/inscritos/index.blade.php ENDPATH**/ ?>