

<?php $__env->startSection('content'); ?>
    <h3>Mis Cursos</h3>

    <div class="row">
    <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-body">
                    <h5><?php echo e($course->title); ?></h5>

                    <a href="<?php echo e(route('student.courses.show', $course->id)); ?>"
                    class="btn btn-success">
                    Entrar al curso
                    </a>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/student/courses/index.blade.php ENDPATH**/ ?>