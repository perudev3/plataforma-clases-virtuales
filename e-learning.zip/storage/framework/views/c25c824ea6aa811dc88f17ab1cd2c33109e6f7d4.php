

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="d-flex justify-content-between mb-3">
        <h4>Mis Cursos</h4>
        <a href="<?php echo e(route('courses.create')); ?>" class="btn btn-primary">
            Crear curso
        </a>
    </div>

    <div class="card shadow-sm">
        <div class="card-body">
            <?php if($courses->count()): ?>
                <table class="table">
                    <thead>
                        <tr>
                            <th>Título</th>
                            <th>Tipo</th>
                            <th>Precio</th>
                            <th>Programa</th>
                            <th>Accion</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($course->title); ?></td>
                                <td>
                                    <?php echo e($course->is_paid === 1 ? 'De pago' : 'Gratis'); ?>

                                </td>
                                <td><?php echo e($course->price); ?></td>
                                <td><?php echo e($course->programa); ?></td>
                                <td>
                                    <a href="<?php echo e(route('syllabus.index', $course->id)); ?>"
                                        class="btn btn-sm btn-outline-primary">
                                        Gestionar Sílabo
                                    </a>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p class="text-muted">Aún no has creado cursos.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/docente/courses/index.blade.php ENDPATH**/ ?>