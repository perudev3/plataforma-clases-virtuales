

<?php $__env->startSection('content'); ?>
<div class="container">

    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>Sílabo – <?php echo e($course->title); ?></h3>

        <button class="btn btn-primary" data-toggle="modal" data-target="#addSyllabusModal">
            + Agregar tema
        </button>
    </div>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <div class="card">
        <div class="card-body p-0">

            <div style="max-height: 420px; overflow-y: auto;">
                <?php $__empty_1 = true; $__currentLoopData = $syllabus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="border-bottom p-3">

                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="mb-1"><?php echo e($item->title); ?></h6>
                                <small class="text-muted"><?php echo e($item->description); ?></small><br>

                                <?php if($item->type === 'video'): ?>
                                    <span class="badge badge-info mt-1">🎥 Video</span>
                                <?php else: ?>
                                    <span class="badge badge-success mt-1">🔗 Zoom</span>
                                <?php endif; ?>
                            </div>

                            <div>
                                <?php if($item->type === 'video'): ?>
                                    <a href="<?php echo e($item->video_url); ?>" target="_blank"
                                       class="btn btn-sm btn-outline-secondary">
                                        Ver video
                                    </a>
                                <?php else: ?>
                                    <a href="<?php echo e($item->zoom_link); ?>" target="_blank"
                                       class="btn btn-sm btn-outline-success">
                                        Entrar a Zoom
                                    </a>
                                <?php endif; ?>
                            </div>
                        </div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-muted text-center p-4">
                        Este curso aún no tiene contenido.
                    </p>
                <?php endif; ?>
            </div>

        </div>
    </div>

</div>


<div class="modal fade" id="addSyllabusModal" tabindex="-1">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">

            <form method="POST" action="<?php echo e(route('syllabus.store', $course)); ?>" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <div class="modal-header">
                    <h5 class="modal-title">Agregar tema</h5>
                    <button type="button" class="close" data-dismiss="modal">
                        &times;
                    </button>
                </div>

                <div class="modal-body">

                    <div class="form-group">
                        <label>Título del tema</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>

                    <div class="form-group">
                        <label>Descripción</label>
                        <textarea name="description" class="form-control" rows="2"></textarea>
                    </div>

                    <div class="form-group">
                        <label>Tipo de contenido</label>
                        <select name="type" id="type" class="form-control" required>
                            <option value="">-- Selecciona --</option>
                            <option value="video">Video</option>
                            <option value="zoom">Zoom</option>
                        </select>
                    </div>

                    <div class="form-group d-none" id="video-field">
                        <label>Subir video</label>
                        <input type="file"
                            name="video_file"
                            class="form-control"
                            accept="video/*">
                    </div>

                    <div class="form-group d-none" id="zoom-field">
                        <label>Link de Zoom</label>
                        <input type="url"
                            name="zoom_link"
                            class="form-control"
                            placeholder="https://zoom.us/..."
                        >
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">
                        Cancelar
                    </button>
                    <button class="btn btn-success">
                        Guardar tema
                    </button>
                </div>

            </form>

        </div>
    </div>
</div>


<script>
document.addEventListener('change', function (e) {

    if (!e.target.matches('#type')) return;

    const videoField = document.getElementById('video-field');
    const zoomField  = document.getElementById('zoom-field');

    // Reset total
    videoField.classList.add('d-none');
    zoomField.classList.add('d-none');

    // Mostrar según selección
    if (e.target.value === 'video') {
        videoField.classList.remove('d-none');
    } 
    else if (e.target.value === 'zoom') {
        zoomField.classList.remove('d-none');
    }

});
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/docente/syllabus/index.blade.php ENDPATH**/ ?>