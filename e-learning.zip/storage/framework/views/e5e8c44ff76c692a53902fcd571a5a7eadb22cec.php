<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'ESIPEC Campus Virtual')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito:400,600,700" rel="stylesheet">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

    <style>
        body {
            font-family: 'Nunito', sans-serif;
            background-color: #F4F6F8;
        }

        .navbar-esipec {
            background-color: #FFFFFF;
            border-bottom: 3px solid #0B2C4D;
        }

        .navbar-brand img {
            max-height: 45px;
        }

        .nav-link {
            color: #0B2C4D !important;
            font-weight: 600;
        }

        .nav-link:hover {
            color: #00B4E6 !important;
        }

        .nav-admin {
            color: #C9A24D !important;
            font-weight: 700;
        }

        .dropdown-menu {
            border-radius: 6px;
            border: none;
            box-shadow: 0 4px 12px rgba(0,0,0,.08);
        }

        main {
            min-height: calc(100vh - 70px);
        }
    </style>
</head>

<body>
<div id="app">

    
    <nav class="navbar navbar-expand-md navbar-light navbar-esipec shadow-sm">
        <div class="container">

            
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                <img src="<?php echo e(asset('images/logo-esipec.png')); ?>" alt="ESIPEC">
            </a>
            <?php if(auth()->guard()->check()): ?>
            <button class="navbar-toggler" type="button"
                    data-toggle="collapse"
                    data-target="#navbarSupportedContent">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">

                
                <ul class="navbar-nav mr-auto">

                  
                        
                        <?php if(Auth::user()->role === 'admin'): ?>
                            <li class="nav-item">
                                <a class="nav-link nav-admin" href="<?php echo e(route('admin.dashboard')); ?>">
                                    Dashboard
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link nav-admin" href="<?php echo e(route('docentes.index')); ?>">
                                    Docentes
                                </a>
                            </li>
                        <?php endif; ?>

                        
                        <?php if(Auth::user()->role === 'teacher'): ?>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('docente.dashboard')); ?>">
                                    Mi Panel
                                </a>
                            </li>

                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(route('docente.courses.index')); ?>">
                                    Mis Cursos
                                </a>
                            </li>

                        <?php endif; ?>

                        
                        <?php if(Auth::user()->role === 'student'): ?>   

                            <li class="nav-item">
                                <a href="<?php echo e(route('alumno.courses.index')); ?>" class="nav-link">
                                    📚 Explorar Cursos
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('alumno.courses')); ?>" class="nav-link">
                                    🎓 Mis Cursos
                                </a>
                            </li>

                        <?php endif; ?>



                    <?php endif; ?>

                </ul>

                
                <ul class="navbar-nav ml-auto">

                    <?php if(auth()->guard()->guest()): ?>
                      
                    <?php else: ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle"
                               href="#"
                               role="button"
                               data-toggle="dropdown">
                                <?php echo e(Auth::user()->name); ?>

                            </a>

                            <div class="dropdown-menu dropdown-menu-right">
                                <a class="dropdown-item"
                                   href="<?php echo e(route('logout')); ?>"
                                   onclick="event.preventDefault();
                                   document.getElementById('logout-form').submit();">
                                    Cerrar sesión
                                </a>

                                <form id="logout-form"
                                      action="<?php echo e(route('logout')); ?>"
                                      method="POST"
                                      class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </li>
                    <?php endif; ?>

                </ul>
            </div>
        </div>
    </nav>

    
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>

</div>
</body>
</html>
<?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/layouts/app.blade.php ENDPATH**/ ?>