

<?php $__env->startSection('content'); ?>
<div class="container">

    <h3 class="mb-4">Nuevo tema – <?php echo e($course->title); ?></h3>

    <form method="POST" action="<?php echo e(route('docente.syllabus.store', $course)); ?>">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Título del tema</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="form-group">
            <label>Descripción</label>
            <textarea name="description" class="form-control"></textarea>
        </div>

        <div class="form-group">
            <label>Tipo de contenido</label>
            <select name="type" id="type" class="form-control">
                <option value="video">Video</option>
                <option value="zoom">Zoom</option>
            </select>
        </div>

        <div class="form-group" id="video-field">
            <label>URL del video</label>
            <input type="text" name="video_url" class="form-control">
        </div>

        <div class="form-group d-none" id="zoom-field">
            <label>Link de Zoom</label>
            <input type="text" name="zoom_link" class="form-control">
        </div>

        <button class="btn btn-success">Guardar tema</button>
        <a href="<?php echo e(route('docente.syllabus.index', $course)); ?>"
           class="btn btn-secondary">
            Volver
        </a>

    </form>

</div>

<script>
document.getElementById('type').addEventListener('change', function () {
    document.getElementById('video-field').classList.toggle('d-none', this.value !== 'video');
    document.getElementById('zoom-field').classList.toggle('d-none', this.value !== 'zoom');
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\plataforma-clases-virtuales\resources\views/docente/syllabus/create.blade.php ENDPATH**/ ?>